// Copyright © 2026 BxKangKi. Licensed under the MIT License.
// Copyright © 2026 Epic Games, Inc. All rights reserved.

/**
 * @file ModelData.cpp
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * UObject and Actor access stays on the game thread; worker tasks receive detached native data only.
 */

#include "Model/ModelData.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/BoxComponent.h"
#include "System/StringHelper.h"
#include "System/JsonHelper.h"
#include "System/MacroLibrary.h"
#include "System/JsonMetadata.h"

// ==========================================
// FModelCollider
// ==========================================

TSharedRef<FJsonObject> FModelCollider::Serialization() const
{
    TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
    FJsonHelper::SetEnumField<EColliderType>(Json, TEXT("Type"), Collider);
    FJsonHelper::SetVector(Json, Center);
    FJsonHelper::SetVector(Json, Size, TEXT("D"));
    return Json;
}

bool FModelCollider::Deserialization(const TSharedPtr<FJsonObject> &Json)
{
    if (!Json.IsValid())
        return false;

    FString Type;
    FJsonHelper::TryGetEnumField<EColliderType>(Json, TEXT("Type"), Collider);
    FJsonHelper::TryGetVector(Json, Center);
    FJsonHelper::TryGetVector(Json, Size, TEXT("D"));
    return true;
}

// ==========================================
// FLightData
// ==========================================

TSharedRef<FJsonObject> FLightData::Serialization() const
{
    TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
    FJsonHelper::SetVector(Json, Location);
    FJsonHelper::SetEnumField<ELightUnits>(Json, TEXT("Unit"), Unit);
    Json->SetNumberField(TEXT("Intensity"), Intensity);
    Json->SetNumberField(TEXT("SourceRadius"), SourceRadius);
    Json->SetNumberField(TEXT("SoftSourceRadius"), SoftSourceRadius);
    Json->SetNumberField(TEXT("AttenuationRadius"), AttenuationRadius);
    Json->SetNumberField(TEXT("Length"), Length);

    return Json;
}

bool FLightData::Deserialization(const TSharedPtr<FJsonObject> &Json)
{
    if (!Json.IsValid())
        return false;

    FJsonHelper::TryGetVector(Json, Location);
    FJsonHelper::TryGetEnumField<ELightUnits>(Json, TEXT("Unit"), Unit);
    Json->TryGetNumberField(TEXT("Intensity"), Intensity);
    Json->TryGetNumberField(TEXT("SourceRadius"), SourceRadius);
    Json->TryGetNumberField(TEXT("SoftSourceRadius"), SoftSourceRadius);
    Json->TryGetNumberField(TEXT("AttenuationRadius"), AttenuationRadius);
    Json->TryGetNumberField(TEXT("Length"), Length);
    return true;
}

// ==========================================
// FMeshData
// ==========================================

TSharedRef<FJsonObject> FMeshData::Serialization() const
{
    TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
    Json->SetBoolField(TEXT("ComplexCollision"), bComplexCollision);
    Json->SetBoolField(TEXT("SimpleCollision"), bSimpleCollision);
    Json->SetBoolField(TEXT("IsEntity"), bIsEntity);

    // Automates TArray struct serialization using a lambda capture.
    FJsonHelper::SetArray<FModelCollider>(Json, TEXT("Colliders"), Colliders, [](const FModelCollider &Item)
                                          { return Item.Serialization(); });

    FJsonHelper::SetArray<FLightData>(Json, TEXT("Lights"), Lights, [](const FLightData &Item)
                                             { return Item.Serialization(); });

    return Json;
}

bool FMeshData::Deserialization(const TSharedPtr<FJsonObject> &Json)
{
    if (!Json.IsValid())
        return false;

    Json->TryGetBoolField(TEXT("ComplexCollision"), bComplexCollision);
    Json->TryGetBoolField(TEXT("SimpleCollision"), bSimpleCollision);
    Json->TryGetBoolField(TEXT("IsEntity"), bIsEntity);

    // Automates TArray struct deserialization.
    FJsonHelper::TryGetArray<FModelCollider>(Json, TEXT("Colliders"), Colliders, [](const TSharedPtr<FJsonObject> &Obj, FModelCollider &OutItem)
                                             { return OutItem.Deserialization(Obj); });

    FJsonHelper::TryGetArray<FLightData>(Json, TEXT("Lights"), Lights, [](const TSharedPtr<FJsonObject> &Obj, FLightData &OutItem)
                                                { return OutItem.Deserialization(Obj); });

    return true;
}

// ==========================================
// FModelData
// ==========================================

TSharedRef<FJsonObject> FModelData::Serialization() const
{
    TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
    Json->SetStringField(V3DSimulatorJsonMetadata::Version, V3DSimulatorJsonMetadata::SchemaVersion);
    // JSON is external, user-authored input. Program-owned bounds are emitted only into .v3d
    // metadata and must never be mixed into this settings document.
    // Automates TMap struct serialization without duplicate loops.
    FJsonHelper::SetMap<FMeshData>(Json, TEXT("MeshData"), MeshData, [](const FMeshData &Item)
                                          { return Item.Serialization(); });

    return Json;
}

bool FModelData::Deserialization(const TSharedPtr<FJsonObject> &Json)
{
    if (!Json.IsValid())
        return false;

    Center = FVector::ZeroVector;
    Size = FVector::ZeroVector;
    MeshData.Empty();
    // Automates TMap struct deserialization while safely restoring JSON keys as FName values.
    FJsonHelper::TryGetMap<FMeshData>(Json, TEXT("MeshData"), MeshData, [](const TSharedPtr<FJsonObject> &Obj, FMeshData &OutItem)
                                             { return OutItem.Deserialization(Obj); });

    return true;
}

