// Copyright © 2026 BxKangKi. Licensed under the MIT License.

#include "System/V3DSimulatorGameInstance.h"
#include "System/V3DSimulatorAssetRegistry.h"
#include "System/ProjectWorkspace.h"
#include "Engine/World.h"
#include "System/SimulatorFileServices.h"
#include "GameMode/MainGameMode.h"
#include "GameMode/GameplayGameModeBase.h"
#include "GameMode/SingleplayGameMode.h"
#include "GameMode/MultiplayGameMode.h"
#include "System/MultiplayerWorldSubSystem.h"
#include "Misc/PackageName.h"

void UV3DSimulatorGameInstance::Init()
{
    FSimulatorFileServices::WriteStartupLog(TEXT("GameInstance Init entered"));
    Super::Init();
    if (!V3DSimulatorProjectWorkspace::EnsureWorkspaceRoots())
    {
        UE_LOG(LogTemp, Error,
            TEXT("V3DSimulator failed to create the Projects, Resources, or Worlds user-data directory."));
    }
    const bool bRegistryReady = EnsureAssetRegistry();
    FSimulatorFileServices::WriteStartupLog(bRegistryReady ? TEXT("AssetRegistry ready") : TEXT("ERROR: AssetRegistry initialization failed"));
    if (bRegistryReady && IsValid(RuntimeAssetRegistry))
    {
        FSimulatorFileServices::WriteStartupLog(FString::Printf(
            TEXT("Registry launch refs: MainWorld=%s MainGM=%s GameplayWorld=%s SingleGM=%s HostWorld=%s MultiGM=%s ClientWorld=%s"),
            *RuntimeAssetRegistry->MainWorld.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->MainGameModeClass.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->GameplayWorld.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->SingleplayGameModeClass.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->HostWorld.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->MultiplayGameModeClass.ToSoftObjectPath().ToString(),
            *RuntimeAssetRegistry->ClientWorld.ToSoftObjectPath().ToString()));
        if (RuntimeAssetRegistry->MainWorld.IsNull())
        {
            UE_LOG(LogTemp, Error,
                TEXT("AssetRegistry.MainWorld is not assigned. MainWorld GameMode cannot be selected from the registry."));
        }
    }
}

bool UV3DSimulatorGameInstance::EnsureAssetRegistry()
{
    if (IsValid(RuntimeAssetRegistry))
    {
        return true;
    }

    RuntimeAssetRegistry = nullptr;
    if (AssetRegistryClass.IsNull())
    {
        AssetRegistryClass = TSoftClassPtr<UV3DSimulatorAssetRegistry>(FSoftObjectPath(
            TEXT("/Game/Blueprints/BP_AssetRegistry.BP_AssetRegistry_C")));
    }

    UClass* RegistryClass = AssetRegistryClass.LoadSynchronous();
    if (!IsValid(RegistryClass)
        || !RegistryClass->IsChildOf(UV3DSimulatorAssetRegistry::StaticClass())
        || RegistryClass->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated | CLASS_NewerVersionExists))
    {
        UE_LOG(LogTemp, Error,
            TEXT("V3DSimulatorGameInstance AssetRegistryClass is invalid or cannot be instantiated. Class=%s"),
            *GetNameSafe(RegistryClass));
        FSimulatorFileServices::WriteStartupLog(TEXT("ERROR: Cannot load AssetRegistry class: ") + AssetRegistryClass.ToSoftObjectPath().ToString());
        return false;
    }

    RuntimeAssetRegistry = NewObject<UV3DSimulatorAssetRegistry>(
        this, RegistryClass, NAME_None, RF_Transient);
    if (!IsValid(RuntimeAssetRegistry))
    {
        UE_LOG(LogTemp, Error,
            TEXT("V3DSimulatorGameInstance failed to create the private runtime asset registry from class %s."),
            *GetNameSafe(RegistryClass));
        return false;
    }

    RuntimeAssetRegistry->EnsureMenuDefaults();

    UE_LOG(LogTemp, Display,
        TEXT("V3DSimulator asset registry initialized from class %s."),
        *GetNameSafe(RegistryClass));
    return true;
}

UV3DSimulatorAssetRegistry* UV3DSimulatorGameInstance::GetAssetRegistry() const
{
    return IsValid(RuntimeAssetRegistry) ? RuntimeAssetRegistry.Get() : nullptr;
}

UV3DSimulatorAssetRegistry* UV3DSimulatorGameInstance::GetAssetRegistryFromContext(const UObject* WorldContextObject)
{
    if (!IsValid(WorldContextObject))
    {
        return nullptr;
    }
    const UWorld* World = WorldContextObject->GetWorld();
    UGameInstance* GameInstance = World ? World->GetGameInstance() : Cast<UGameInstance>(const_cast<UObject*>(WorldContextObject));
    if (UV3DSimulatorGameInstance* SimulatorGameInstance = Cast<UV3DSimulatorGameInstance>(GameInstance))
    {
        // Init normally creates this before any world starts. The fallback makes direct/editor world
        // startup robust if a custom lifecycle calls into the registry unusually early.
        SimulatorGameInstance->EnsureAssetRegistry();
        return SimulatorGameInstance->GetAssetRegistry();
    }
    return nullptr;
}

namespace V3DGameInstancePrivate
{
    // Strip only the engine PIE prefix on the package leaf, preserving the full folder path.
    FString CanonicalMapPackage(const FString& MapName)
    {
        FString Package = FPackageName::ObjectPathToPackageName(MapName);
        int32 Slash = INDEX_NONE;
        Package.FindLastChar(TEXT('/'), Slash);
        const FString Folder = Package.Left(Slash + 1);
        FString Leaf = Package.Mid(Slash + 1);
        if (Leaf.StartsWith(TEXT("UEDPIE_")))
        {
            int32 Separator = Leaf.Find(TEXT("_"), ESearchCase::CaseSensitive, ESearchDir::FromStart, 7);
            if (Separator > 7 && Leaf.Mid(7, Separator - 7).IsNumeric())
            {
                Leaf = Leaf.Mid(Separator + 1);
            }
        }
        return Folder + Leaf;
    }

    FString SoftWorldPackage(const TSoftObjectPtr<UWorld>& WorldAsset)
    {
        return WorldAsset.IsNull()
            ? FString()
            : CanonicalMapPackage(WorldAsset.ToSoftObjectPath().GetLongPackageName());
    }

    bool MapMatchesSoftWorld(const FString& MapName, const TSoftObjectPtr<UWorld>& WorldAsset)
    {
        const FString Expected = SoftWorldPackage(WorldAsset);
        if (Expected.IsEmpty())
        {
            return false;
        }

        const FString Actual = CanonicalMapPackage(MapName);
        if (Actual.Equals(Expected, ESearchCase::IgnoreCase))
        {
            return true;
        }

        // Some engine paths provide only the short map name to OverrideGameModeClass. In that case
        // compare against the explicitly configured destination, never against a guessed hard-coded name.
        if (!Actual.Contains(TEXT("/")))
        {
            return FPackageName::GetShortName(Actual).Equals(
                FPackageName::GetShortName(Expected), ESearchCase::IgnoreCase);
        }
        return false;
    }

    UClass* LoadValidatedGameModeClass(
        const TSoftClassPtr<AGameModeBase>& SoftClass,
        UClass* RequiredBaseClass,
        const TCHAR* Label)
    {
        UClass* SelectedClass = SoftClass.LoadSynchronous();
        if (!IsValid(SelectedClass)
            || !SelectedClass->IsChildOf(RequiredBaseClass)
            || SelectedClass->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated | CLASS_NewerVersionExists))
        {
            FSimulatorFileServices::WriteStartupLog(FString::Printf(
                TEXT("ERROR: Invalid %s GameMode class: %s"),
                Label,
                *SoftClass.ToSoftObjectPath().ToString()));
            return nullptr;
        }
        return SelectedClass;
    }
}

TSubclassOf<AGameModeBase> UV3DSimulatorGameInstance::OverrideGameModeClass(
    TSubclassOf<AGameModeBase> GameModeClass, const FString& MapName,
    const FString& Options, const FString& Portal) const
{
    const UV3DSimulatorAssetRegistry* Registry = GetAssetRegistry();
    if (!IsValid(Registry))
    {
        FSimulatorFileServices::WriteStartupLog(TEXT("ERROR: GameMode selection has no runtime AssetRegistry"));
        return Super::OverrideGameModeClass(GameModeClass, MapName, Options, Portal);
    }

    // MainWorld always wins over any stale gameplay launch state. The request is cleared from
    // AMainGameMode::BeginPlay after the menu map has been constructed successfully.
    if (V3DGameInstancePrivate::MapMatchesSoftWorld(MapName, Registry->MainWorld))
    {
        TSoftClassPtr<AGameModeBase> MainMode(Registry->MainGameModeClass.ToSoftObjectPath());
        if (MainMode.IsNull())
        {
            MainMode = AMainGameMode::StaticClass();
        }

        if (UClass* SelectedClass = V3DGameInstancePrivate::LoadValidatedGameModeClass(
                MainMode, AMainGameMode::StaticClass(), TEXT("MainWorld")))
        {
            FSimulatorFileServices::WriteStartupLog(FString::Printf(
                TEXT("Registry selected MainWorld GameMode: Map=%s World=%s Class=%s"),
                *MapName,
                *Registry->MainWorld.ToSoftObjectPath().ToString(),
                *SelectedClass->GetPathName()));
            return SelectedClass;
        }

        // A broken configured Blueprint must not make the menu map instantiate an unrelated project
        // default. The native menu mode is a deterministic last-resort implementation.
        FSimulatorFileServices::WriteStartupLog(TEXT("MainWorld GameMode validation failed; using native AMainGameMode"));
        return AMainGameMode::StaticClass();
    }

    // Gameplay travel stores an exact (World, GameMode, external-folder) tuple in a GameInstance
    // subsystem before OpenLevel. Match the exact destination map here, before Unreal spawns its
    // authoritative GameMode. This is the single source of truth for local/host gameplay travel.
    if (const UMultiplayerWorldSubSystem* Multiplayer = UMultiplayerWorldSubSystem::Get(this))
    {
        const TSoftObjectPtr<UWorld> RequestedWorld = Multiplayer->GetRequestedWorldAsset();
        const TSoftClassPtr<AGameModeBase> RequestedGameMode = Multiplayer->GetRequestedGameModeOverride();
        if (!RequestedWorld.IsNull()
            && !RequestedGameMode.IsNull()
            && V3DGameInstancePrivate::MapMatchesSoftWorld(MapName, RequestedWorld))
        {
            if (UClass* SelectedClass = V3DGameInstancePrivate::LoadValidatedGameModeClass(
                    RequestedGameMode,
                    AV3DSimulatorGameplayGameModeBase::StaticClass(),
                    TEXT("gameplay")))
            {
                FSimulatorFileServices::WriteStartupLog(FString::Printf(
                    TEXT("Launch descriptor selected gameplay GameMode: Map=%s World=%s Folder=%s Class=%s"),
                    *MapName,
                    *RequestedWorld.ToSoftObjectPath().ToString(),
                    *Multiplayer->GetRequestedGameModeWorldFolder(),
                    *SelectedClass->GetPathName()));
                return SelectedClass;
            }

            // A normal menu launch validates this class before OpenLevel, so this branch is only a
            // last-resort safety path for direct Blueprint/API travel. Never fall through to an
            // unrelated map/project GameMode: keep the simulator lifecycle owner deterministic.
            FSimulatorFileServices::WriteStartupLog(FString::Printf(
                TEXT("ERROR: Explicit gameplay GameMode could not be loaded for destination %s; using native simulator mode"),
                *RequestedWorld.ToSoftObjectPath().ToString()));
            return Multiplayer->GetWorldMode() == EMultiplayerWorldMode::Host
                ? TSubclassOf<AGameModeBase>(AMultiplayGameMode::StaticClass())
                : TSubclassOf<AGameModeBase>(ASingleplayGameMode::StaticClass());
        }
    }

    return Super::OverrideGameModeClass(GameModeClass, MapName, Options, Portal);
}
