// Copyright © 2026 BxKangKi. Licensed under the MIT License.
// Copyright © 2026 Epic Games, Inc. All rights reserved.

/**
 * File role: V3DRuntimeSafety.cpp
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * UObject and Actor access stays on the game thread; worker tasks receive detached native data only.
 */

/**
 * @file V3DRuntimeSafety.cpp
 * @brief Bounded-parallel mesh scheduling, exclusive parser/cache barriers, and session quarantine.
 */
#include "System/V3DRuntimeSafety.h"
#include "HAL/CriticalSection.h"
#include "HAL/FileManager.h"
#include "HAL/IConsoleManager.h"

#include "Async/Async.h"
#include "Async/TaskGraphInterfaces.h"
#include "Containers/Ticker.h"
#include "HAL/PlatformProcess.h"
#include "HAL/PlatformMisc.h"
#include "HAL/PlatformTime.h"
#include "HAL/ThreadSafeCounter.h"
#include "Misc/ScopeExit.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/ScopeLock.h"
#include "System/GlbValidation.h"
#include "System/SafeFileIO.h"
#include "UObject/StrongObjectPtr.h"
#include "glTFRuntimeAsset.h"
#include "glTFRuntimeParser.h"

namespace V3DRuntimeSafetyPrivate
{
    /** One native operation waiting for a slot. Queue state is game-thread-only. */
    struct FQueuedOperation
    {
        uint64 Ticket = 0;
        TWeakObjectPtr<UObject> Owner;
        TWeakObjectPtr<UglTFRuntimeAsset> Asset;
        FString Label;
        FV3DRuntimeSafety::FQueuedStart Start;
        FV3DRuntimeSafety::FRejected Rejected;
        bool bExclusive = false;
    };

    /** Metadata retained while one native operation owns a slot. */
    struct FActiveOperation
    {
        FActiveOperation(
            const uint64 InTicket,
            UObject* InOwner,
            UglTFRuntimeAsset* InAsset,
            FString InLabel,
            const double InStartedAtSeconds,
            const bool bInExclusive)
            : Ticket(InTicket)
            , Owner(InOwner)
            , Asset(InAsset)
            , Label(MoveTemp(InLabel))
            , StartedAtSeconds(InStartedAtSeconds)
            , bExclusive(bInExclusive)
        {
        }

        uint64 Ticket = 0;
        // Once native work starts, both UObjects must outlive every plugin callback. Queued jobs
        // remain weak so cancellation can discard them, but active jobs deliberately become strong.
        TStrongObjectPtr<UObject> Owner;
        TStrongObjectPtr<UglTFRuntimeAsset> Asset;
        FString Label;
        double StartedAtSeconds = 0.0;
        bool bExclusive = false;
    };

    /**
     * A strong reference is required while the original actor/action is dropping its UPROPERTY.
     * The reference is released only after ClearCache has run on the game thread.
     */
    struct FPendingAssetRelease
    {
        explicit FPendingAssetRelease(UglTFRuntimeAsset* InAsset)
            : Asset(InAsset)
        {
        }

        TStrongObjectPtr<UglTFRuntimeAsset> Asset;
    };

    struct FFailureRecord
    {
        int32 Count = 0;
        FString LastReason;
        int64 FileSize = INDEX_NONE;
        FDateTime Timestamp;
    };

    void CaptureSourceFingerprint(const FString& NormalizedPath, int64& OutFileSize, FDateTime& OutTimestamp)
    {
        OutFileSize = IFileManager::Get().FileSize(*NormalizedPath);
        OutTimestamp = OutFileSize == INDEX_NONE
            ? FDateTime()
            : IFileManager::Get().GetTimeStamp(*NormalizedPath);
    }

    bool HasSourceFingerprintChanged(const FString& NormalizedPath, const FFailureRecord& Record)
    {
        // URI-style runtime references do not have a disk fingerprint. Their records are cleared on
        // success or by an explicit retry, while real source GLBs are invalidated automatically
        // after the author edits/replaces the file.
        if (NormalizedPath.StartsWith(TEXT("gworld://"), ESearchCase::CaseSensitive))
        {
            return false;
        }

        int64 CurrentSize = INDEX_NONE;
        FDateTime CurrentTimestamp;
        CaptureSourceFingerprint(NormalizedPath, CurrentSize, CurrentTimestamp);
        return CurrentSize != Record.FileSize || CurrentTimestamp != Record.Timestamp;
    }

    struct FState
    {
        // Parser construction, synchronous loads and cache teardown remain globally exclusive.
        // Independent RuntimeLOD mesh finalizers are counted separately and may run in parallel.
        // The mutex protects only coordinator state; it is never held while third-party code executes.
        FCriticalSection NativeGateLock;
        enum class ENativePhase : uint8 { Idle, ParserCreation, MeshOperation, QueuedExclusive, SynchronousOperation, CacheClear };
        ENativePhase NativePhase = ENativePhase::Idle;
        // RuntimeLOD finalizers use independent parser/build contexts and may execute concurrently.
        // Parser creation, synchronous plugin calls, and cache teardown remain exclusive against all
        // mesh finalizers to preserve the original safety boundary around shared plugin state.
        int32 ActiveMeshOperations = 0;

        // Failure records are queried by both game and worker threads.
        FCriticalSection FailureLock;
        TMap<FString, FFailureRecord> Failures;

        // Control flags are read by both game-thread and worker-thread entry points.
        FThreadSafeCounter CircuitOpenFlag;
        FThreadSafeCounter ShuttingDownFlag;
        FCriticalSection ControlLock;
        FString CircuitReason;

        // Everything below is game-thread-only. Keeping a single owning thread avoids a second
        // synchronization layer around UObject weak/strong pointer transitions and callbacks.
        TArray<FQueuedOperation> Queue;
        TMap<uint64, FActiveOperation> ActiveOperations;
        TArray<FPendingAssetRelease> PendingAssetReleases;
        uint64 NextTicket = 1;
        bool bPumpingQueue = false;
        FTSTicker::FDelegateHandle WatchdogHandle;
    };

    FState& GetState()
    {
        static FState State;
        return State;
    }

    FString NormalizeFailureKey(const FString& SourceOrReference)
    {
        FString Clean = SourceOrReference.TrimStartAndEnd();
        if (Clean.StartsWith(TEXT("gworld://"), ESearchCase::CaseSensitive))
        {
            Clean.ToLowerInline();
            return Clean;
        }
        return GlbValidation::NormalizePath(Clean);
    }

    constexpr int32 MaximumQueuedOperations = 4096;

    TAutoConsoleVariable<int32> CVarMaximumConcurrentNativeOperations(
        TEXT("gltfsim.Streaming.MaxConcurrentMeshBuilds"),
        0,
        TEXT("Maximum number of independent baked RuntimeLOD glTFRuntime mesh finalizers. ")
        TEXT("0 = auto (physical cores - 1, clamped to 1..8); explicit values clamp to 1..16."),
        ECVF_Default);

    int32 GetMaximumConcurrentNativeOperations()
    {
        const int32 Configured = CVarMaximumConcurrentNativeOperations.GetValueOnGameThread();
        if (Configured > 0)
        {
            return FMath::Clamp(Configured, 1, 16);
        }
        return FMath::Clamp(FPlatformMisc::NumberOfCores() - 1, 1, 8);
    }

    bool IsShuttingDown()
    {
        return GetState().ShuttingDownFlag.GetValue() != 0;
    }

    bool IsCircuitOpen(FString* OutReason = nullptr)
    {
        FState& State = GetState();
        const bool bOpen = State.CircuitOpenFlag.GetValue() != 0;
        if (bOpen && OutReason)
        {
            FScopeLock ControlScope(&State.ControlLock);
            *OutReason = State.CircuitReason;
        }
        return bOpen;
    }

    void OpenCircuit(const FString& Reason)
    {
        FState& State = GetState();
        {
            FScopeLock ControlScope(&State.ControlLock);
            State.CircuitReason = Reason.Left(2048);
        }
        if (State.CircuitOpenFlag.GetValue() == 0)
        {
            State.CircuitOpenFlag.Increment();
        }
    }

    void RejectOperation(FQueuedOperation& Operation, const FString& Reason)
    {
        if (Operation.Rejected)
        {
            Operation.Rejected(Reason);
        }
    }

    bool IsAssetActive(const FState& State, const UglTFRuntimeAsset* Asset)
    {
        if (!Asset)
        {
            return false;
        }

        for (const TPair<uint64, FActiveOperation>& Pair : State.ActiveOperations)
        {
            if (Pair.Value.Asset.Get() == Asset)
            {
                return true;
            }
        }
        return false;
    }

    bool IsAssetPendingRelease(const FState& State, const UglTFRuntimeAsset* Asset)
    {
        if (!Asset)
        {
            return false;
        }

        for (const FPendingAssetRelease& Pending : State.PendingAssetReleases)
        {
            if (Pending.Asset.Get() == Asset)
            {
                return true;
            }
        }
        return false;
    }

    /** Moves matching queue entries out before invoking rejection callbacks, avoiding re-entrant mutation. */
    TArray<FQueuedOperation> RemoveQueuedOperationsForOwner(FState& State, const UObject* Owner)
    {
        TArray<FQueuedOperation> Removed;
        if (!Owner)
        {
            return Removed;
        }

        for (int32 Index = State.Queue.Num() - 1; Index >= 0; --Index)
        {
            if (State.Queue[Index].Owner.Get() == Owner)
            {
                Removed.Add(MoveTemp(State.Queue[Index]));
                State.Queue.RemoveAtSwap(Index, 1, EAllowShrinking::No);
            }
        }
        return Removed;
    }

    /** Moves every queued operation for one asset out before callbacks are invoked. */
    TArray<FQueuedOperation> RemoveQueuedOperationsForAsset(FState& State, const UglTFRuntimeAsset* Asset)
    {
        TArray<FQueuedOperation> Removed;
        if (!Asset)
        {
            return Removed;
        }

        for (int32 Index = State.Queue.Num() - 1; Index >= 0; --Index)
        {
            if (State.Queue[Index].Asset.Get() == Asset)
            {
                Removed.Add(MoveTemp(State.Queue[Index]));
                State.Queue.RemoveAtSwap(Index, 1, EAllowShrinking::No);
            }
        }
        return Removed;
    }

    bool TryEnterNativePhase(const FState::ENativePhase Phase)
    {
        FState& State = GetState();
        FScopeLock Lock(&State.NativeGateLock);

        if (Phase == FState::ENativePhase::MeshOperation)
        {
            // Every baked finalizer owns a distinct UglTFRuntimeAsset/parser. Allow several of those
            // independent contexts to build at once, but never overlap an exclusive parser/cache
            // phase. Global concurrency is bounded again by PumpQueue_GameThread().
            if (State.NativePhase != FState::ENativePhase::Idle)
            {
                return false;
            }
            ++State.ActiveMeshOperations;
            return true;
        }

        if (State.NativePhase != FState::ENativePhase::Idle || State.ActiveMeshOperations > 0)
        {
            return false;
        }
        State.NativePhase = Phase;
        return true;
    }

    void LeaveNativePhase(const FState::ENativePhase Phase)
    {
        FState& State = GetState();
        FScopeLock Lock(&State.NativeGateLock);
        if (Phase == FState::ENativePhase::MeshOperation)
        {
            ensureMsgf(State.ActiveMeshOperations > 0, TEXT("glTFRuntime mesh-operation gate underflow"));
            State.ActiveMeshOperations = FMath::Max(0, State.ActiveMeshOperations - 1);
            return;
        }

        ensureMsgf(State.NativePhase == Phase, TEXT("glTFRuntime native gate phase mismatch"));
        if (State.NativePhase == Phase)
        {
            State.NativePhase = FState::ENativePhase::Idle;
        }
    }

    bool IsNativeGateIdle()
    {
        FState& State = GetState();
        FScopeLock Lock(&State.NativeGateLock);
        return State.NativePhase == FState::ENativePhase::Idle;
    }

    /** Worker-thread RAII token for the single process-wide native gate. */
    class FParserCreationSlot
    {
    public:
        bool Acquire()
        {
            while (!IsShuttingDown() && !IsCircuitOpen())
            {
                if (TryEnterNativePhase(FState::ENativePhase::ParserCreation))
                {
                    bHeld = true;
                    return true;
                }

                // Parser creation is already performed on the shared worker pool. A short sleep
                // avoids a hot spin while preserving cancellation/shutdown responsiveness.
                FPlatformProcess::SleepNoStats(0.001f);
            }
            return false;
        }

        ~FParserCreationSlot()
        {
            Release();
        }

        void Release()
        {
            if (!bHeld) return;
            LeaveNativePhase(FState::ENativePhase::ParserCreation);
            bHeld = false;
        }

    private:
        bool bHeld = false;
    };
}

TSharedPtr<FglTFRuntimeParser> FV3DRuntimeSafety::CreateParserSafely(
    const FString& FilePath,
    const FglTFRuntimeConfig& Config,
    FString* OutError)
{
    if (OutError)
    {
        OutError->Reset();
    }

    auto Fail = [OutError](const FString& Reason) -> TSharedPtr<FglTFRuntimeParser>
    {
        if (OutError)
        {
            *OutError = Reason;
        }
        return nullptr;
    };

    if (IsInGameThread())
    {
        const FString Reason = TEXT("glTFRuntime parser construction was requested on the game thread");
        UE_LOG(LogTemp, Error, TEXT("%s: %s"), *Reason, *FilePath);
        return Fail(Reason);
    }

    FString CoordinatorReason;
    if (V3DRuntimeSafetyPrivate::IsShuttingDown())
    {
        const FString Reason = TEXT("glTFRuntime coordinator is shutting down");
        UE_LOG(LogTemp, Warning, TEXT("Refused glTFRuntime parser construction during shutdown: %s"), *FilePath);
        return Fail(Reason);
    }
    if (V3DRuntimeSafetyPrivate::IsCircuitOpen(&CoordinatorReason))
    {
        const FString Reason = FString::Printf(TEXT("glTFRuntime safety circuit is open: %s"), *CoordinatorReason);
        UE_LOG(LogTemp, Error,
            TEXT("Refused glTFRuntime parser because the safety circuit is open. Path=%s Reason=%s"),
            *FilePath,
            *CoordinatorReason);
        return Fail(Reason);
    }

    FString QuarantineReason;
    if (IsPathQuarantined(FilePath, &QuarantineReason))
    {
        const FString Reason = FString::Printf(TEXT("source is quarantined from an earlier failure: %s"), *QuarantineReason);
        UE_LOG(LogTemp, Error, TEXT("Refused quarantined glTF file. Path=%s Reason=%s"),
            *FilePath,
            *QuarantineReason);
        return Fail(Reason);
    }

    V3DRuntimeSafetyPrivate::FParserCreationSlot ParserSlot;
    if (!ParserSlot.Acquire())
    {
        return Fail(TEXT("glTFRuntime parser gate could not be acquired"));
    }

    // Each request creates a distinct parser and mutable cache. The single construction slot avoids
    // overlapping large native allocations while map startup discovers several independent GLBs.
    if (V3DRuntimeSafetyPrivate::IsShuttingDown() ||
        V3DRuntimeSafetyPrivate::IsCircuitOpen(&CoordinatorReason))
    {
        return Fail(CoordinatorReason.IsEmpty()
            ? TEXT("glTFRuntime parser creation was cancelled")
            : CoordinatorReason);
    }

    TSharedPtr<FglTFRuntimeParser> Parser = FglTFRuntimeParser::FromFilename(FilePath, Config);

    // FromFilename is glTFRuntime's normal path and is also what its official async loader uses.
    // If it fails after our own GLB preflight successfully opened the same file, retry once from
    // bytes. This avoids platform/path-layer false negatives while preserving the source directory
    // for any explicitly external URI referenced by an otherwise valid GLB.
    if (!Parser.IsValid() && FPaths::FileExists(FilePath))
    {
        TArray64<uint8> FileBytes;
        if (FFileHelper::LoadFileToArray(FileBytes, *FilePath))
        {
            FglTFRuntimeConfig FallbackConfig = Config;
            FallbackConfig.bSearchContentDir = false;
            if (FallbackConfig.bAllowExternalFiles && FallbackConfig.OverrideBaseDirectory.IsEmpty())
            {
                FallbackConfig.OverrideBaseDirectory = FPaths::GetPath(FilePath);
            }
            Parser = FglTFRuntimeParser::FromData(
                FileBytes.GetData(), FileBytes.Num(), FallbackConfig);
            if (Parser.IsValid())
            {
                UE_LOG(LogTemp, Warning,
                    TEXT("glTFRuntime FromFilename failed but direct-data fallback succeeded. Path=%s"),
                    *FilePath);
            }
        }
    }

    ParserSlot.Release();
    // This continuation participates in the same shutdown drain as the worker that constructed
    // the parser, preventing a raw module callback from surviving DLL unload.
    FSafeFileIO::DispatchTrackedGameThread([]()
    {
        FV3DRuntimeSafety::NotifyGateAvailable_GameThread();
    });

    if (!Parser.IsValid())
    {
        return Fail(FString::Printf(
            TEXT("glTFRuntime rejected the GLB after validated filename and direct-data load attempts (size=%lld)"),
            IFileManager::Get().FileSize(*FilePath)));
    }

    ClearRecoverableFailure(FilePath);
    return Parser;
}

bool FV3DRuntimeSafety::ExecuteSynchronousOperation(
    const FString& Label,
    TFunctionRef<void()> Operation)
{
    if (!ensureMsgf(IsInGameThread(), TEXT("Synchronous glTFRuntime work must run on the game thread")))
    {
        return false;
    }
    FString Reason;
    if (V3DRuntimeSafetyPrivate::IsShuttingDown() ||
        V3DRuntimeSafetyPrivate::IsCircuitOpen(&Reason) ||
        !V3DRuntimeSafetyPrivate::TryEnterNativePhase(
            V3DRuntimeSafetyPrivate::FState::ENativePhase::SynchronousOperation))
    {
        UE_LOG(LogTemp, Error,
            TEXT("Rejected synchronous glTFRuntime operation because the global native gate is busy. Label=%s Reason=%s"),
            *Label, Reason.IsEmpty() ? TEXT("another native operation is active") : *Reason);
        return false;
    }

    {
        ON_SCOPE_EXIT
        {
            V3DRuntimeSafetyPrivate::LeaveNativePhase(
                V3DRuntimeSafetyPrivate::FState::ENativePhase::SynchronousOperation);
        };
        Operation();
    }

    // Operation() and its plugin stack have fully returned and the scope guard has released the
    // gate. Pump synchronously to remove watchdog latency without leaving an untracked module
    // callback queued across shutdown/DLL unload.
    NotifyGateAvailable_GameThread();
    return true;
}

uint64 FV3DRuntimeSafety::EnqueueOperation(
    UObject* Owner,
    UglTFRuntimeAsset* Asset,
    const FString& Label,
    FQueuedStart Start,
    FRejected Rejected)
{
    return EnqueueOperationInternal(
        Owner, Asset, Label, MoveTemp(Start), MoveTemp(Rejected), false);
}

uint64 FV3DRuntimeSafety::EnqueueExclusiveOperation(
    UObject* Owner,
    UglTFRuntimeAsset* Asset,
    const FString& Label,
    FQueuedStart Start,
    FRejected Rejected)
{
    return EnqueueOperationInternal(
        Owner, Asset, Label, MoveTemp(Start), MoveTemp(Rejected), true);
}

uint64 FV3DRuntimeSafety::EnqueueOperationInternal(
    UObject* Owner,
    UglTFRuntimeAsset* Asset,
    const FString& Label,
    FQueuedStart Start,
    FRejected Rejected,
    const bool bExclusive)
{
    // Queue entry points return a ticket synchronously. Silently redispatching from a worker would
    // return 0 to the caller while a real request starts later, leaving its in-flight/ticket state
    // unsynchronized. All project call sites are GT-guarded, so reject misuse instead.
    if (!ensureMsgf(IsInGameThread(), TEXT("FV3DRuntimeSafety queue operations must run on the game thread")))
    {
        return 0;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    if (!State.WatchdogHandle.IsValid())
    {
        State.WatchdogHandle = FTSTicker::GetCoreTicker().AddTicker(
            FTickerDelegate::CreateStatic(&FV3DRuntimeSafety::TickWatchdog),
            1.0f);
    }

    FString CoordinatorReason;
    const bool bPendingRelease = V3DRuntimeSafetyPrivate::IsAssetPendingRelease(State, Asset);
    if (V3DRuntimeSafetyPrivate::IsShuttingDown() ||
        V3DRuntimeSafetyPrivate::IsCircuitOpen(&CoordinatorReason) ||
        !IsValid(Owner) || !IsValid(Asset) || !Start || bPendingRelease ||
        State.Queue.Num() >= V3DRuntimeSafetyPrivate::MaximumQueuedOperations)
    {
        if (Rejected)
        {
            if (V3DRuntimeSafetyPrivate::IsShuttingDown())
            {
                Rejected(TEXT("glTFRuntime coordinator is shutting down"));
            }
            else if (!CoordinatorReason.IsEmpty())
            {
                Rejected(CoordinatorReason);
            }
            else if (bPendingRelease)
            {
                Rejected(TEXT("The glTFRuntime asset is already pending safe release"));
            }
            else if (!IsValid(Owner) || !IsValid(Asset) || !Start)
            {
                Rejected(TEXT("Operation owner, runtime asset, or start callback is invalid"));
            }
            else
            {
                Rejected(TEXT("The glTFRuntime queue reached its safety limit"));
            }
        }
        return 0;
    }

    V3DRuntimeSafetyPrivate::FQueuedOperation Operation;
    Operation.Ticket = State.NextTicket++;
    Operation.Owner = Owner;
    Operation.Asset = Asset;
    Operation.Label = Label.Left(512);
    Operation.Start = MoveTemp(Start);
    Operation.Rejected = MoveTemp(Rejected);
    Operation.bExclusive = bExclusive;
    const uint64 Ticket = Operation.Ticket;
    State.Queue.Add(MoveTemp(Operation));
    PumpQueue_GameThread();
    return Ticket;
}

void FV3DRuntimeSafety::CompleteOperation(const uint64 Ticket)
{
    if (!IsInGameThread())
    {
        // Do not route this through FSafeFileIO: its shutdown gate intentionally rejects new
        // dispatches. The active-ticket map itself keeps this module and both UObjects logically
        // alive until this game-thread completion removes the ticket during the shutdown drain.
        // During normal play, register a one-shot ticker instead of completing the operation inside
        // a GameThread task spawned by a plugin worker. UE 5.8 propagates FAppTime through task
        // ancestry; such a task can run on the game thread with no inherited frame-time context and
        // then start renderer work from an invalid context. The ticker executes on a normal frame.
        // Shutdown is different: no new native operation will be started, and the shutdown drain
        // pumps TaskGraph but not FTSTicker, so complete directly through the pumped GameThread task.
        if (V3DRuntimeSafetyPrivate::IsShuttingDown())
        {
            AsyncTask(ENamedThreads::GameThread, [Ticket]()
            {
                FV3DRuntimeSafety::CompleteOperation(Ticket);
            });
        }
        else
        {
            AsyncTask(ENamedThreads::GameThread, [Ticket]()
            {
                FTSTicker::GetCoreTicker().AddTicker(
                    FTickerDelegate::CreateLambda([Ticket](float)
                    {
                        FV3DRuntimeSafety::CompleteOperation(Ticket);
                        return false;
                    }),
                    0.0f);
            });
        }
        return;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    if (Ticket == 0 || !State.ActiveOperations.Contains(Ticket))
    {
        return;
    }

    const V3DRuntimeSafetyPrivate::FActiveOperation* Active = State.ActiveOperations.Find(Ticket);
    const bool bExclusive = Active && Active->bExclusive;
    State.ActiveOperations.Remove(Ticket);
    V3DRuntimeSafetyPrivate::LeaveNativePhase(
        bExclusive
            ? V3DRuntimeSafetyPrivate::FState::ENativePhase::QueuedExclusive
            : V3DRuntimeSafetyPrivate::FState::ENativePhase::MeshOperation);

    // A release requested during the callback is finalized before another job can reuse that parser.
    ProcessPendingAssetReleases_GameThread();
    PumpQueue_GameThread();
}

void FV3DRuntimeSafety::CompleteOperationAfterCallback(const uint64 Ticket)
{
    if (Ticket == 0)
    {
        return;
    }

    // Always defer until the next core-ticker frame. glTFRuntime executes the project delegate
    // before its async context calls UnregisterGCObject(); releasing the ticket inline could run
    // ClearCache against a callback wrapper that has not finished unwinding. A ticker also preserves
    // UE 5.8's normal frame-time context for any queued operation started by CompleteOperation().
    if (V3DRuntimeSafetyPrivate::IsShuttingDown())
    {
        AsyncTask(ENamedThreads::GameThread, [Ticket]()
        {
            FV3DRuntimeSafety::CompleteOperation(Ticket);
        });
        return;
    }

    auto RegisterCompletionTicker = [Ticket]()
    {
        FTSTicker::GetCoreTicker().AddTicker(
            FTickerDelegate::CreateLambda([Ticket](float)
            {
                FV3DRuntimeSafety::CompleteOperation(Ticket);
                return false;
            }),
            0.0f);
    };

    if (IsInGameThread())
    {
        RegisterCompletionTicker();
    }
    else
    {
        AsyncTask(ENamedThreads::GameThread, MoveTemp(RegisterCompletionTicker));
    }
}

void FV3DRuntimeSafety::CancelQueuedOperations(UObject* Owner)
{
    // Constructing/reading weak UObject pointers and mutating the queue are deliberately kept on
    // one owning thread. Every project caller is a UObject lifecycle or callback path on the GT.
    if (!ensureMsgf(IsInGameThread(), TEXT("FV3DRuntimeSafety::CancelQueuedOperations must run on the game thread")))
    {
        return;
    }

    if (!Owner)
    {
        return;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    TArray<V3DRuntimeSafetyPrivate::FQueuedOperation> Removed =
        V3DRuntimeSafetyPrivate::RemoveQueuedOperationsForOwner(State, Owner);
    for (V3DRuntimeSafetyPrivate::FQueuedOperation& Operation : Removed)
    {
        V3DRuntimeSafetyPrivate::RejectOperation(Operation, TEXT("Operation was cancelled before it started"));
    }

    ProcessPendingAssetReleases_GameThread();
    PumpQueue_GameThread();
}

void FV3DRuntimeSafety::RequestAssetRelease(UglTFRuntimeAsset* Asset)
{
    // The caller must transfer the last strong reference on the game thread. Silently posting a
    // weak pointer from a worker would leave a GC window before the deferred release can own it.
    if (!ensureMsgf(IsInGameThread(), TEXT("FV3DRuntimeSafety::RequestAssetRelease must run on the game thread")))
    {
        return;
    }

    if (!IsValid(Asset))
    {
        return;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    if (V3DRuntimeSafetyPrivate::IsAssetPendingRelease(State, Asset))
    {
        return;
    }

    // Acquire the strong reference before callers null their UPROPERTY. This closes the GC window
    // between actor teardown and a terminal native callback.
    State.PendingAssetReleases.Emplace(Asset);

    TArray<V3DRuntimeSafetyPrivate::FQueuedOperation> Removed =
        V3DRuntimeSafetyPrivate::RemoveQueuedOperationsForAsset(State, Asset);
    for (V3DRuntimeSafetyPrivate::FQueuedOperation& Operation : Removed)
    {
        V3DRuntimeSafetyPrivate::RejectOperation(
            Operation,
            TEXT("Operation was cancelled because its glTFRuntime asset is being released"));
    }

    ProcessPendingAssetReleases_GameThread();
    PumpQueue_GameThread();
}

void FV3DRuntimeSafety::ProcessPendingAssetReleases_GameThread()
{
    check(IsInGameThread());
    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();

    for (int32 Index = State.PendingAssetReleases.Num() - 1; Index >= 0; --Index)
    {
        UglTFRuntimeAsset* Asset = State.PendingAssetReleases[Index].Asset.Get();
        if (!IsValid(Asset))
        {
            State.PendingAssetReleases.RemoveAtSwap(Index, 1, EAllowShrinking::No);
            continue;
        }

        if (V3DRuntimeSafetyPrivate::IsAssetActive(State, Asset))
        {
            continue;
        }

        if (!V3DRuntimeSafetyPrivate::TryEnterNativePhase(
            V3DRuntimeSafetyPrivate::FState::ENativePhase::CacheClear))
        {
            return;
        }

        // ClearCache touches the parser's mutable cache and shares the process-wide native gate
        // with every parser constructor and mesh operation.
        Asset->ClearCache();
        if (Asset->IsRooted())
        {
            Asset->RemoveFromRoot();
        }
        Asset->ClearFlags(RF_Public | RF_Standalone);
        State.PendingAssetReleases.RemoveAtSwap(Index, 1, EAllowShrinking::No);
        V3DRuntimeSafetyPrivate::LeaveNativePhase(
            V3DRuntimeSafetyPrivate::FState::ENativePhase::CacheClear);
    }
}

void FV3DRuntimeSafety::NotifyGateAvailable_GameThread()
{
    check(IsInGameThread());
    ProcessPendingAssetReleases_GameThread();
    PumpQueue_GameThread();
}

void FV3DRuntimeSafety::ReportRecoverableFailure(
    const FString& FilePath,
    const FString& Reason)
{
    const FString NormalizedPath = V3DRuntimeSafetyPrivate::NormalizeFailureKey(FilePath);
    if (NormalizedPath.IsEmpty())
    {
        return;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    FScopeLock FailureScope(&State.FailureLock);
    V3DRuntimeSafetyPrivate::FFailureRecord& Record = State.Failures.FindOrAdd(NormalizedPath);

    // Editing/replacing a source GLB is a new input and must not inherit a previous file's failure
    // count merely because it kept the same path. This also makes Live Coding authoring retries sane.
    if (Record.Count > 0
        && V3DRuntimeSafetyPrivate::HasSourceFingerprintChanged(NormalizedPath, Record))
    {
        Record = V3DRuntimeSafetyPrivate::FFailureRecord();
    }

    if (Record.Count == 0)
    {
        V3DRuntimeSafetyPrivate::CaptureSourceFingerprint(
            NormalizedPath, Record.FileSize, Record.Timestamp);
    }
    ++Record.Count;
    Record.LastReason = Reason.Left(2048);

    if (Record.Count == 2)
    {
        UE_LOG(LogTemp, Error,
            TEXT("Quarantined model source/reference after %d recoverable failures. Key=%s Reason=%s"),
            Record.Count,
            *NormalizedPath,
            *Record.LastReason);
    }
}

void FV3DRuntimeSafety::ClearRecoverableFailure(const FString& FilePath)
{
    const FString NormalizedPath = V3DRuntimeSafetyPrivate::NormalizeFailureKey(FilePath);
    if (NormalizedPath.IsEmpty())
    {
        return;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    FScopeLock FailureScope(&State.FailureLock);
    State.Failures.Remove(NormalizedPath);
}

void FV3DRuntimeSafety::ResetRecoverableFailures()
{
    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    FScopeLock FailureScope(&State.FailureLock);
    State.Failures.Reset();
}

bool FV3DRuntimeSafety::IsPathQuarantined(
    const FString& FilePath,
    FString* OutReason)
{
    const FString NormalizedPath = V3DRuntimeSafetyPrivate::NormalizeFailureKey(FilePath);
    if (NormalizedPath.IsEmpty())
    {
        return false;
    }

    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    FScopeLock FailureScope(&State.FailureLock);

    V3DRuntimeSafetyPrivate::FFailureRecord* Record = State.Failures.Find(NormalizedPath);
    if (Record && Record->Count > 0
        && V3DRuntimeSafetyPrivate::HasSourceFingerprintChanged(NormalizedPath, *Record))
    {
        State.Failures.Remove(NormalizedPath);
        Record = nullptr;
        UE_LOG(LogTemp, Display,
            TEXT("Cleared stale glTF quarantine because the source changed. Path=%s"),
            *NormalizedPath);
    }

    const bool bQuarantined = Record && Record->Count >= 2;
    if (bQuarantined && OutReason)
    {
        *OutReason = Record->LastReason;
    }
    return bQuarantined;
}

bool FV3DRuntimeSafety::IsCircuitOpen(FString* OutReason)
{
    return V3DRuntimeSafetyPrivate::IsCircuitOpen(OutReason);
}

void FV3DRuntimeSafety::BeginShutdown()
{
    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();

    // Raise the atomic flag immediately so worker-thread parser requests stop before queue cleanup.
    if (State.ShuttingDownFlag.GetValue() == 0)
    {
        State.ShuttingDownFlag.Increment();
    }

    if (!IsInGameThread())
    {
        FSafeFileIO::DispatchTrackedGameThread([]()
        {
            FV3DRuntimeSafety::BeginShutdown();
        });
        return;
    }

    TArray<V3DRuntimeSafetyPrivate::FQueuedOperation> Removed = MoveTemp(State.Queue);
    State.Queue.Reset();
    for (V3DRuntimeSafetyPrivate::FQueuedOperation& Operation : Removed)
    {
        V3DRuntimeSafetyPrivate::RejectOperation(Operation, TEXT("glTFRuntime coordinator is shutting down"));
    }

    ProcessPendingAssetReleases_GameThread();
    if (State.WatchdogHandle.IsValid())
    {
        FTSTicker::GetCoreTicker().RemoveTicker(State.WatchdogHandle);
        State.WatchdogHandle.Reset();
    }
}

bool FV3DRuntimeSafety::FlushPendingOperations(const double TimeoutSeconds)
{
    if (!ensureMsgf(IsInGameThread(), TEXT("FV3DRuntimeSafety::FlushPendingOperations must run on the game thread")))
    {
        return false;
    }

    const double StartSeconds = FPlatformTime::Seconds();
    while (GetPendingOperationCount() > 0)
    {
        if (TimeoutSeconds >= 0.0 && FPlatformTime::Seconds() - StartSeconds >= TimeoutSeconds)
        {
            return false;
        }

        // Plugin callbacks are marshalled to the game thread. Pump them so terminal callbacks can
        // return their tickets and finalize deferred cache releases before this module unloads.
        FTaskGraphInterface::Get().ProcessThreadUntilIdle(ENamedThreads::GameThread);
        ProcessPendingAssetReleases_GameThread();
        FPlatformProcess::SleepNoStats(0.005f);
    }
    return true;
}

int32 FV3DRuntimeSafety::GetPendingOperationCount()
{
    if (!ensureMsgf(IsInGameThread(), TEXT("glTFRuntime queue state must be read on the game thread")))
    {
        return 0;
    }

    const V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    return State.Queue.Num() + State.ActiveOperations.Num() + State.PendingAssetReleases.Num();
}

int32 FV3DRuntimeSafety::GetMeshBuildConcurrencyLimit()
{
    if (!ensureMsgf(IsInGameThread(), TEXT("glTFRuntime mesh concurrency must be read on the game thread")))
    {
        return 1;
    }
    return V3DRuntimeSafetyPrivate::GetMaximumConcurrentNativeOperations();
}

bool FV3DRuntimeSafety::TickWatchdog(const float DeltaSeconds)
{
    (void)DeltaSeconds;
    check(IsInGameThread());

    constexpr double NativeOperationTimeoutSeconds = 180.0;
    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    if (V3DRuntimeSafetyPrivate::IsShuttingDown())
    {
        return false;
    }
    NotifyGateAvailable_GameThread();
    if (V3DRuntimeSafetyPrivate::IsCircuitOpen() || State.ActiveOperations.IsEmpty())
    {
        return true;
    }

    const double NowSeconds = FPlatformTime::Seconds();
    const V3DRuntimeSafetyPrivate::FActiveOperation* TimedOut = nullptr;
    for (const TPair<uint64, V3DRuntimeSafetyPrivate::FActiveOperation>& Pair : State.ActiveOperations)
    {
        if (Pair.Value.StartedAtSeconds > 0.0 &&
            NowSeconds - Pair.Value.StartedAtSeconds >= NativeOperationTimeoutSeconds)
        {
            TimedOut = &Pair.Value;
            break;
        }
    }

    if (!TimedOut)
    {
        return true;
    }

    const FString CircuitReason = FString::Printf(
        TEXT("glTFRuntime circuit breaker opened after operation [%llu] '%s' exceeded %.0f seconds"),
        TimedOut->Ticket,
        *TimedOut->Label,
        NativeOperationTimeoutSeconds);
    V3DRuntimeSafetyPrivate::OpenCircuit(CircuitReason);
    UE_LOG(LogTemp, Error, TEXT("%s. No additional glTFRuntime jobs will start this session."), *CircuitReason);

    TArray<V3DRuntimeSafetyPrivate::FQueuedOperation> Removed = MoveTemp(State.Queue);
    State.Queue.Reset();
    for (V3DRuntimeSafetyPrivate::FQueuedOperation& Operation : Removed)
    {
        V3DRuntimeSafetyPrivate::RejectOperation(Operation, CircuitReason);
    }
    return true;
}

void FV3DRuntimeSafety::PumpQueue_GameThread()
{
    check(IsInGameThread());
    V3DRuntimeSafetyPrivate::FState& State = V3DRuntimeSafetyPrivate::GetState();
    if (State.bPumpingQueue || V3DRuntimeSafetyPrivate::IsShuttingDown() ||
        V3DRuntimeSafetyPrivate::IsCircuitOpen())
    {
        return;
    }

    State.bPumpingQueue = true;
    ON_SCOPE_EXIT
    {
        State.bPumpingQueue = false;
    };

    const int32 MaximumConcurrentNativeOperations =
        V3DRuntimeSafetyPrivate::GetMaximumConcurrentNativeOperations();
    while (State.ActiveOperations.Num() < MaximumConcurrentNativeOperations &&
        V3DRuntimeSafetyPrivate::IsNativeGateIdle())
    {
        int32 SelectedIndex = INDEX_NONE;
        TArray<V3DRuntimeSafetyPrivate::FQueuedOperation> RejectedBeforeStart;
        V3DRuntimeSafetyPrivate::FQueuedOperation Operation;
        bool bHasSelectedOperation = false;

        // Preserve queue order and reject stale entries before selecting the next bounded-parallel
        // native operation. The per-builder test remains as a defensive invariant.
        for (int32 Index = 0; Index < State.Queue.Num(); ++Index)
        {
            V3DRuntimeSafetyPrivate::FQueuedOperation& Candidate = State.Queue[Index];
            UObject* Owner = Candidate.Owner.Get();
            UglTFRuntimeAsset* Asset = Candidate.Asset.Get();

            if (!IsValid(Owner) || !IsValid(Asset) || !Candidate.Start ||
                V3DRuntimeSafetyPrivate::IsAssetPendingRelease(State, Asset))
            {
                RejectedBeforeStart.Add(MoveTemp(Candidate));
                State.Queue.RemoveAt(Index, 1, EAllowShrinking::No);
                --Index;
                continue;
            }

            if (Candidate.bExclusive)
            {
                // Exclusive source-parser/capture work is a queue barrier. Once it reaches the
                // head of the runnable region, let already-active mesh finalizers drain instead of
                // admitting later mesh work indefinitely and starving the authoring operation.
                if (State.ActiveOperations.Num() == 0)
                {
                    SelectedIndex = Index;
                }
                break;
            }

            if (!V3DRuntimeSafetyPrivate::IsAssetActive(State, Asset))
            {
                SelectedIndex = Index;
                break;
            }
        }

        if (SelectedIndex != INDEX_NONE)
        {
            // Remove and register the selected entry before invoking any rejection callback.
            // Callbacks are user code and may otherwise mutate Queue and invalidate SelectedIndex.
            Operation = MoveTemp(State.Queue[SelectedIndex]);
            State.Queue.RemoveAt(SelectedIndex, 1, EAllowShrinking::No);

            const V3DRuntimeSafetyPrivate::FState::ENativePhase RequestedPhase =
                Operation.bExclusive
                    ? V3DRuntimeSafetyPrivate::FState::ENativePhase::QueuedExclusive
                    : V3DRuntimeSafetyPrivate::FState::ENativePhase::MeshOperation;
            if (!V3DRuntimeSafetyPrivate::TryEnterNativePhase(RequestedPhase))
            {
                // A worker parser acquired the gate between the idle probe and this claim.
                // Restore queue order; parser completion will pump the queue on the game thread.
                State.Queue.Insert(MoveTemp(Operation), 0);
                for (V3DRuntimeSafetyPrivate::FQueuedOperation& Rejected : RejectedBeforeStart)
                {
                    V3DRuntimeSafetyPrivate::RejectOperation(
                        Rejected,
                        TEXT("Operation owner/asset expired or the asset entered safe release before execution"));
                }
                return;
            }

            V3DRuntimeSafetyPrivate::FActiveOperation Active(
                Operation.Ticket,
                Operation.Owner.Get(),
                Operation.Asset.Get(),
                Operation.Label,
                FPlatformTime::Seconds(),
                Operation.bExclusive);
            State.ActiveOperations.Add(Active.Ticket, MoveTemp(Active));
            bHasSelectedOperation = true;
        }

        if (!bHasSelectedOperation)
        {
            // Rejection callbacks are user code and may enqueue/cancel more work. Invoke them only
            // after the queue scan has finished so callback re-entry cannot invalidate Queue indices.
            for (V3DRuntimeSafetyPrivate::FQueuedOperation& Rejected : RejectedBeforeStart)
            {
                V3DRuntimeSafetyPrivate::RejectOperation(
                    Rejected,
                    TEXT("Operation owner/asset expired or the asset entered safe release before execution"));
            }

            // A rejection callback may have appended a newly runnable operation. Re-scan once the
            // callbacks are complete; otherwise there is no runnable asset until an active job ends.
            if (!RejectedBeforeStart.IsEmpty())
            {
                continue;
            }
            return;
        }

        UE_LOG(LogTemp, Verbose,
            TEXT("Starting %s glTFRuntime operation [%llu] %s (active=%d/%d)"),
            Operation.bExclusive ? TEXT("exclusive") : TEXT("bounded-parallel"),
            Operation.Ticket,
            *Operation.Label,
            State.ActiveOperations.Num(),
            MaximumConcurrentNativeOperations);

        // Start may synchronously fail and call CompleteOperation. The bPumpingQueue guard prevents
        // recursive pumping while this outer loop safely observes the updated active map.
        Operation.Start(Operation.Ticket);

        // Start the selected operation before invoking unrelated rejection callbacks. Otherwise a
        // rejection callback could request release of the just-selected asset after it was marked
        // active but before native work actually began.
        for (V3DRuntimeSafetyPrivate::FQueuedOperation& Rejected : RejectedBeforeStart)
        {
            V3DRuntimeSafetyPrivate::RejectOperation(
                Rejected,
                TEXT("Operation owner/asset expired or the asset entered safe release before execution"));
        }
    }
}
