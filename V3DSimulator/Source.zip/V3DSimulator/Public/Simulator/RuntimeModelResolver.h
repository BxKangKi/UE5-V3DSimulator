// Copyright © 2026 BxKangKi. Licensed under the MIT License.

/**
 * @file RuntimeModelResolver.h
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * Declares interface, lifetime, and data-ownership contracts; see the matching implementation for behavior.
 */

#pragma once

#include "CoreMinimal.h"
#include "Simulator/ModelDefinitionJson.h"

class FGWorldArchiveReader;
class UWorldBakedModelAsset;
struct FGWorldModelManifest;
struct FGWorldModelMetadata;

/** Immutable lookup result safe to capture in a worker after it was assembled on the game thread. */
struct V3DSIMULATOR_API FResolvedRuntimeModel
{
    FGuid UUID;
    FModelDefinition Definition;
    FString Reference;
    FString DefinitionJson;
    TSharedPtr<FGWorldArchiveReader, ESPMode::ThreadSafe> ArchiveReader;

    bool IsValid() const;
};

/**
 * Single runtime gateway for built models. It intentionally has no filename fallback: source GLBs
 * are consumed only by the project builder, never by gameplay actors after startup.
 */
class V3DSIMULATOR_API FRuntimeModelResolver
{
public:
    /** Game-thread lookup against the immutable model directory. */
    static bool Resolve(
        const UObject* WorldContextObject,
        const FString& Reference,
        FResolvedRuntimeModel& OutModel,
        FString& OutError);

    /**
     * Creates a lightweight facade containing only node metadata and .dat ranges. No GLB byte
     * array or source-document parser is created at runtime.
     */
    static UWorldBakedModelAsset* LoadAssetSynchronously(
        const FResolvedRuntimeModel& Model,
        FString& OutError);

    /**
     * Publishes metadata/manifest tables that were already read on a worker thread. This bypasses
     * both definition-detail I/O and synchronous archive reads on the game thread while preserving
     * the same weak facade cache used by every other runtime model consumer.
     */
    static UWorldBakedModelAsset* LoadAssetFromPreparedTables(
        const FGuid& UUID,
        const FString& Reference,
        const TSharedPtr<FGWorldArchiveReader, ESPMode::ThreadSafe>& ArchiveReader,
        FGWorldModelMetadata&& Metadata,
        FGWorldModelManifest&& Manifest,
        FString& OutError);
};
