// Copyright © 2026 BxKangKi. Licensed under the MIT License.

/**
 * @file CharacterBoneSchema.h
 * Canonical character-bone schema shared by JSON validation, world baking, and runtime loading.
 */

#pragma once

#include "CoreMinimal.h"

class FJsonObject;
class USkeleton;
struct FReferenceSkeleton;

namespace CharacterBoneSchema
{
    /** The canonical JSON keys are fixed. Source bone-name values are author-defined. */
    V3DSIMULATOR_API const TArray<FName>& GetRequiredKeys();

    /**
     * Validates a canonical-key -> source-bone JSON object and converts it to the source -> canonical
     * alias map required by glTFRuntime. Missing, extra, empty, or duplicate source mappings fail.
     */
    V3DSIMULATOR_API bool BuildSourceToCanonicalMap(
        const TSharedPtr<FJsonObject>& BonesObject,
        TMap<FString, FString>& OutAliases,
        FString& OutError);

    /** Validates the internal source-bone -> canonical-key representation stored in built archives. */
    V3DSIMULATOR_API bool ValidateSourceToCanonicalMap(
        const TMap<FString, FString>& Aliases,
        FString& OutError);

    /** Every required canonical bone must exist exactly once in the reference skeleton. */
    V3DSIMULATOR_API bool ValidateCanonicalReferenceSkeleton(
        const FReferenceSkeleton& ReferenceSkeleton,
        FString& OutError);

    V3DSIMULATOR_API bool ValidateCanonicalSkeleton(
        const USkeleton* Skeleton,
        FString& OutError);

    /** Ensures the final runtime mesh preserved the canonical target skeleton hierarchy. */
    V3DSIMULATOR_API bool ValidateCanonicalHierarchyMatches(
        const FReferenceSkeleton& Candidate,
        const FReferenceSkeleton& Target,
        FString& OutError);

    /**
     * The character bake copies canonical target rotations into the archived reference pose while
     * preserving the source rig's proportions. Reject stale archives whose canonical rotations no
     * longer match the configured target skeleton instead of committing a visibly twisted mesh.
     */
    V3DSIMULATOR_API bool ValidateCanonicalReferenceRotationsMatch(
        const FReferenceSkeleton& Candidate,
        const FReferenceSkeleton& Target,
        float ToleranceDegrees,
        FString& OutError);
}
