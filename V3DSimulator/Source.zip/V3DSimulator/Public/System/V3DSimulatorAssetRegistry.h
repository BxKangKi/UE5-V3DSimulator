// Copyright © 2026 BxKangKi. Licensed under the MIT License.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Model/MaterialDefaultAsset.h"
#include "V3DSimulatorAssetRegistry.generated.h"

class AActor;
class AGameModeBase;
class AMainGameMode;
class ASingleplayGameMode;
class AMultiplayGameMode;
class AStaticActor;
class ADynamicActor;
class AVehiclePawn;
class AWeaponActor;
class AWeaponProjectileActor;
class AWorldEnvManager;
class AWaterActor;
class UCreatorHUDWidget;
class UPauseMenuWidget;
class USettingsMenuWidget;
class UBuildStatusWidget;
class UStartWorldWidget;
class UWorldSelectionWidget;
class UProjectSelectionWidget;
class UMenuButtonWidget;
class UBooleanSettingWidget;
class UFloatSettingWidget;
class UEnumSettingWidget;
class UMaterialInterface;
class UMaterialParameterCollection;
class UStaticMesh;
class USkeletalMesh;
class UPhysicsAsset;
class UPhysicalMaterial;
class USkeleton;
class USoundBase;
class UInputMappingContext;
class UInputAction;
class UAnimInstance;
class UNiagaraSystem;
class UUserWidget;
class UWorld;


USTRUCT(BlueprintType)
struct V3DSIMULATOR_API FV3DSimulatorFootstepBinding
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character|Footsteps")
    TSoftObjectPtr<UPhysicalMaterial> PhysicalMaterial;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character|Footsteps")
    TSoftObjectPtr<USoundBase> Sound;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character|Footsteps")
    TSoftObjectPtr<UNiagaraSystem> Effect;
};

USTRUCT(BlueprintType)
struct V3DSIMULATOR_API FV3DWorldLaunchProfile
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="World Launch")
    FString WorldFolderName;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="World Launch")
    TSoftObjectPtr<UWorld> SinglePlayerWorld;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="World Launch")
    TSoftObjectPtr<UWorld> HostWorld;

};

USTRUCT(BlueprintType)
struct V3DSIMULATOR_API FV3DSimulatorInputMappingContextConfig
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputMappingContext> MappingContext;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    int32 Priority = 50;
};

/**
 * Project-wide editor asset registry.
 *
 * The custom GameInstance creates one private transient instance from AssetRegistryClass. Every
 * heavyweight asset/class/world inside the registry is a soft reference, so creating the registry does not make those
 * packages resident. Runtime systems resolve only what they need and keep a reflected strong
 * reference for exactly as long as the resolved asset is in use.
 */
UCLASS(BlueprintType, Blueprintable)
class V3DSIMULATOR_API UV3DSimulatorAssetRegistry : public UDataAsset
{
    GENERATED_BODY()

public:
    UV3DSimulatorAssetRegistry(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

    /** Repairs missing built-in menu classes and the legacy project-widget redirector path. */
    void EnsureMenuDefaults();

    // Native actor classes can be replaced by Blueprint subclasses without forcing them to load at startup.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AStaticActor> StaticActorClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<ADynamicActor> DynamicActorClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AVehiclePawn> VehiclePawnClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AWeaponActor> WeaponActorClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AWeaponProjectileActor> WeaponProjectileActorClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AWorldEnvManager> WorldEnvManagerClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AWaterActor> WaterActorClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Actors")
    TSoftClassPtr<AActor> RainWeatherActorClass;

    // UI classes are soft references. GameMode/PlayerController create missing top-level instances automatically at runtime.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UStartWorldWidget> StartMenuWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UWorldSelectionWidget> WorldSelectionWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UStartWorldWidget> MultiplayerMenuWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UProjectSelectionWidget> ProjectSelectionWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UPauseMenuWidget> PauseMenuWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<USettingsMenuWidget> SettingsMenuWidgetClass;

    /** WBP subclass of UBuildStatusWidget shown while a Projects entry is being built. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UBuildStatusWidget> BuildStatusWidgetClass;

    /** Shared generated selection-entry WBP used by Project and World selection lists. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI|Common")
    TSoftClassPtr<UMenuButtonWidget> SelectionEntryWidgetClass;

    /** Shared generated Confirm button WBP used by the build-status view. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI|Common")
    TSoftClassPtr<UMenuButtonWidget> BuildStatusConfirmWidgetClass;

    /** Shared generated row WBP for boolean settings. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI|Common")
    TSoftClassPtr<UBooleanSettingWidget> BooleanSettingWidgetClass;

    /** Shared generated row WBP for ranged numeric settings. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI|Common")
    TSoftClassPtr<UFloatSettingWidget> FloatSettingWidgetClass;

    /** Shared generated row WBP for discrete/enum settings. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI|Common")
    TSoftClassPtr<UEnumSettingWidget> EnumSettingWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UCreatorHUDWidget> CreatorHUDWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UUserWidget> DebugWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="UI")
    TSoftClassPtr<UUserWidget> LoadingWidgetClass;

    // Menu/navigation worlds. Soft references prevent menu maps from being resident in gameplay.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Worlds")
    TSoftObjectPtr<UWorld> GameplayWorld;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Worlds")
    TSoftObjectPtr<UWorld> HostWorld;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Worlds")
    TSoftObjectPtr<UWorld> ClientWorld;

    /** Single MainWorld. Start, world selection, multiplayer, project build and settings are UI states inside this same map. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Worlds")
    TSoftObjectPtr<UWorld> MainWorld;

    /** Selected by GameInstance before MainWorld's GameMode is spawned. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Game Modes")
    TSoftClassPtr<AMainGameMode> MainGameModeClass;

    /** Gameplay GameMode classes used as explicit travel overrides when the common gameplay map is shared. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Game Modes")
    TSoftClassPtr<ASingleplayGameMode> SingleplayGameModeClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Game Modes")
    TSoftClassPtr<AMultiplayGameMode> MultiplayGameModeClass;

    /** Optional per-world map overrides. GameMode selection is fixed by SingleplayGameModeClass / MultiplayGameModeClass. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Worlds", meta=(TitleProperty="WorldFolderName"))
    TArray<FV3DWorldLaunchProfile> WorldLaunchProfiles;

    // Rendering/default assets.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Rendering")
    TSoftObjectPtr<UMaterialInterface> PlacementGridMaterial;

    /** Default glTF material soft references live directly in this one central data object. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Rendering")
    FV3DMaterialSoftAssetReferences V3DMaterials;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Rendering")
    TSoftObjectPtr<UMaterialInterface> StaticDecalLightMaterial;

    /** One unbound post-process material containing cel shading and global ocean underwater effects. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Rendering")
    TSoftObjectPtr<UMaterialInterface> GlobalPostProcessMaterial;

    /** Shared shader parameter collection used by global post-process/environment shaders. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Rendering")
    TSoftObjectPtr<UMaterialParameterCollection> ShaderLibraryMPC;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Environment")
    TSoftObjectPtr<UStaticMesh> SkyboxMesh;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Environment")
    TSoftObjectPtr<UMaterialInterface> CloudMaterial;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Water")
    TSoftObjectPtr<UStaticMesh> WaterMesh;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Water")
    TSoftObjectPtr<UMaterialInterface> WaterDecalMaterial;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Water")
    TSoftObjectPtr<UMaterialInterface> UnderWaterMaterial;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Weapon")
    TSoftObjectPtr<UStaticMesh> DefaultWeaponMesh;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character")
    TSoftObjectPtr<USkeletalMesh> DefaultCharacterSkeletalMesh;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character")
    TSoftObjectPtr<UPhysicsAsset> DefaultCharacterPhysicsAsset;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character")
    TSoftObjectPtr<USkeleton> DefaultCharacterSkeleton;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character")
    TSoftObjectPtr<UMaterialInterface> DefaultCharacterMaterial;

    /** Animation Blueprint class applied to the character mesh. The class is loaded only when a character begins play. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character")
    TSoftClassPtr<UAnimInstance> DefaultCharacterAnimInstanceClass;

    /** Loaded on demand: sound/effect assets are resolved only when their surface is actually stepped on. */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Character|Footsteps")
    TArray<FV3DSimulatorFootstepBinding> FootstepBindings;

    // Enhanced Input is centralized for the same reason: controller Blueprints no longer hard-reference assets.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputMappingContext> PrimaryInputMappingContext;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    int32 PrimaryInputMappingPriority = 50;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TArray<FV3DSimulatorInputMappingContextConfig> AdditionalInputMappingContexts;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> MoveAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> LookAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> JumpAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> SprintAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> CrouchAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> FlyAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> RagdollAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> InteractAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> ToggleFirstPersonAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> ChangeCharacterAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> ToolbarScrollAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> ToggleItemListAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> SnapAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> VehicleMoveAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> VehicleThrottleAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> VehicleSteeringAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> VehicleStopAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> PauseAction;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Input")
    TSoftObjectPtr<UInputAction> DebugAction;
};
