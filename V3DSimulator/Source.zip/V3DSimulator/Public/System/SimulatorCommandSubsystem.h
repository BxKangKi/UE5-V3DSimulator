// Copyright © 2026 BxKangKi. Licensed under the MIT License.

/**
 * @file SimulatorCommandSubsystem.h
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * Declares interface, lifetime, and data-ownership contracts; see the matching implementation for behavior.
 */

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "TimerManager.h"
#include "SimulatorCommandSubsystem.generated.h"

class APlayerController;

/**
 * Single parser/executor for simulator commands.
 *
 * PlayerController console input is only one frontend. A future chat widget can pass exactly the
 * same command line to ExecuteCommand without duplicating parsing, permission, or validation code.
 */
UCLASS()
class V3DSIMULATOR_API USimulatorCommandSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    virtual void Deinitialize() override;

    /** Returns true when CommandLine begins with a simulator command, even if its arguments are invalid. */
    bool ExecuteCommand(APlayerController* RequestingController, const FString& CommandLine, FString& OutMessage);

    /** Lightweight recognizer used before deciding whether a client command should be sent to authority. */
    static bool IsSimulatorCommand(const TCHAR* CommandLine);

private:
    bool ExecuteWeather(APlayerController* Controller, const TArray<FString>& Args, FString& OutMessage);
    bool ExecuteTime(APlayerController* Controller, const TArray<FString>& Args, FString& OutMessage);
    bool ExecuteTeleport(APlayerController* Controller, const TArray<FString>& Args, FString& OutMessage);

    struct FPendingTeleportRequest
    {
        TWeakObjectPtr<APlayerController> RequestingController;
        TWeakObjectPtr<APlayerController> TargetController;
        FVector Destination = FVector::ZeroVector;
        FString TargetName;
        double StartedAtSeconds = 0.0;
        bool bActive = false;
    };

    FPendingTeleportRequest PendingTeleport;
    FTimerHandle PendingTeleportTimer;
    static constexpr float TeleportPollIntervalSeconds = 0.05f;
    static constexpr double TeleportLoadTimeoutSeconds = 120.0;

    bool PrepareTeleportDestination(UWorld* World, const FVector& Destination) const;
    void SchedulePendingTeleportCheck();
    void ProcessPendingTeleport();
    void ClearTeleportStreamingFocus();
    void ResetPendingTeleport();
    void SendTeleportStatus(const FString& Message) const;

    static void Tokenize(const FString& Input, TArray<FString>& OutTokens);
    static bool ParseFiniteDouble(const FString& Token, double& OutValue);
    static APlayerController* ResolveTargetPlayer(APlayerController* RequestingController, const FString& PlayerName);
};
