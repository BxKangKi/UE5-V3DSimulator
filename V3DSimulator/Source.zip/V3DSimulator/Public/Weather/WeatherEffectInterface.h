// Copyright © 2026 BxKangKi. Licensed under the MIT License.

/**
 * @file WeatherEffectInterface.h
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * Declares interface, lifetime, and data-ownership contracts; see the matching implementation for behavior.
 */

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "WeatherEffectInterface.generated.h"

class USceneComponent;

/**
 * Optional Blueprint hook for editor-assigned weather actors (for example BP_Rain).
 *
 * The runtime weather subsystem does not require this interface: an actor that does not implement
 * it is still spawned, attached to the active camera, and destroyed when weather clears. Implement
 * the interface only when the Blueprint needs explicit preset/intensity/activation callbacks.
 */
UINTERFACE(BlueprintType)
class V3DSIMULATOR_API UWeatherEffectInterface : public UInterface
{
    GENERATED_BODY()
};

class V3DSIMULATOR_API IWeatherEffectInterface
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Weather")
    void SetWeatherCamera(USceneComponent* CameraComponent);

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Weather")
    void SetWeatherPreset(const FString& Preset);

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Weather")
    void SetWeatherIntensity(float Intensity);

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Weather")
    void SetWeatherActive(bool bActive);
};
