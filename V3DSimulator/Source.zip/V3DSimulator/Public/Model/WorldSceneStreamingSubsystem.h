// Copyright © 2026 BxKangKi. Licensed under the MIT License.

/**
 * @file WorldSceneStreamingSubsystem.h
 * Role: Defines this source unit's responsibility within V3DSimulator.
 * Key responsibilities: Implements the behavior exposed by this source unit's public API.
 * Declares interface, lifetime, and data-ownership contracts; see the matching implementation for behavior.
 */

#pragma once

#include "CoreMinimal.h"
#include "Model/ModelData.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "TimerManager.h"
#include "WorldSceneStreamingSubsystem.generated.h"

class AActor;
class ACharacterController;
class AStaticActor;

/**
 * A scene row copied from the small .v3d root directory.
 *
 * This is intentionally metadata-only: keeping these rows resident is cheap, while the large
 * decoded .dat ranges stay on disk until EnsureSceneActor decides that the player is close enough.
 */
struct FWorldSceneStreamRecord
{
    FGuid UUID;
    FString RuntimeReference;
    FModelData Bounds;
};

/** Immutable character selector. The runtime reference is a gworld:// UUID, never a file path. */
struct FWorldCharacterStreamRecord
{
    FGuid UUID;
    FString RuntimeReference;
    FString Name;
    FString DisplayName;
};

/**
 * Distance streamer for static scene models and the selected player character.
 *
 * All discovery comes from UModelDatabaseSubsystem's already-open .v3d directory. This class
 * never scans project authoring files, never opens a source GLB, and never maintains a second metadata cache.
 * A scene actor is created only inside its coarse archive bounds; AStaticActor then range-reads that
 * model's detailed metadata and requested decoded .dat members through the shared archive reader.
 */
UCLASS()
class V3DSIMULATOR_API UWorldSceneStreamingSubsystem final : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    static UWorldSceneStreamingSubsystem* Get(UObject* WorldContextObject);

    virtual void Deinitialize() override;

    void StartWorldStreaming(
        AActor* InOwnerActor,
        const FString& InWorldRoot,
        const FString& InInitialPlayerName,
        bool bInRenderOnlyStreaming = false);
    void StopWorldStreaming();

    bool AreInitialModelsReady() const;
    bool IsInitialWorldReady();
    bool IsPlayerLoaded() const;
    float GetLoadingStatus() const;

    /** Preloads a destination without moving the player; current and destination areas may coexist. */
    void SetPriorityStreamingFocus(const FVector& WorldLocation);
    void ClearPriorityStreamingFocus();
    bool IsLocationReady(const FVector& WorldLocation) const;
    /** Primary streaming observer. Priority preload focus wins while one is active. */
    FVector GetStreamingLocation() const;
    /** All active observers, with the priority preload target first and the live player retained. */
    void GetStreamingObserverLocations(TArray<FVector>& OutLocations) const;

    UFUNCTION(BlueprintCallable, Category="World|Streaming|Player")
    bool CycleNextPlayerCharacter();

    /** Mutates game-thread-owned streaming state. Worker-thread calls are rejected. */
    void SetRenderOnlyStreaming(bool bInRenderOnlyStreaming);
    bool IsRenderOnlyStreaming() const;

    /** True only while this persistent GameInstance subsystem belongs to World. */
    bool IsActiveForWorld(const UWorld* World) const;

    /**
     * Reports a terminal startup rejection without exposing mutable streamer state.
     * GameManager uses this to stop its next-tick loading poll instead of waiting forever.
     */
    bool HasStartupFailed() const;

private:
    UPROPERTY()
    TObjectPtr<AActor> OwnerActor;

    /** Strong references exist only for scenes currently inside the streaming radius. */
    UPROPERTY()
    TMap<FString, TObjectPtr<AStaticActor>> ActiveSceneActors;

    TArray<FWorldSceneStreamRecord> SceneRecords;
    TArray<FWorldCharacterStreamRecord> CharacterRecords;
    TSet<FString> FailedCharacterReferences;

    FString WorldRoot;
    FString InitialPlayerName;
    FString CurrentCharacterReference;
    FString PendingCharacterReference;
    int32 CurrentCharacterIndex = INDEX_NONE;
    int32 PendingCharacterIndex = INDEX_NONE;

    bool bActive = false;
    bool bStartupFailed = false;
    bool bInitialScenePassComplete = false;
    bool bInitialPlayerLoadStarted = false;
    bool bInitialPlayerLoadComplete = false;
    bool bWaitingForPlayerLoad = false;
    bool bPendingPlayerIsInitialLoad = false;
    bool bPlayerActivated = false;
    bool bRenderOnlyStreaming = false;
    bool bInitialBurstUpdateQueued = false;
    bool bHasPriorityStreamingFocus = false;
    FVector PriorityStreamingFocus = FVector::ZeroVector;

    TWeakObjectPtr<ACharacterController> ActivePlayerCharacter;
    double PlayerActorWaitStartedAt = 0.0;
    double PlayerLoadStartedAt = 0.0;

    /** UI-only monotonic smoothing; it never delays actual archive reads or readiness. */
    mutable float LastReportedLoadingStatus = 0.0f;
    mutable uint64 LastLoadingProgressFrame = ~uint64(0);

    FTimerHandle TimerHandle_UpdateStreaming;
    FTimerHandle TimerHandle_WaitPlayer;

    void UpdateStreaming();
    void QueueInitialStreamingBurst();
    void RunInitialStreamingBurst();
    void ScheduleStreamingUpdates();
    FVector GetPlayerLocation() const;
    AStaticActor* EnsureSceneActor(const FWorldSceneStreamRecord& Record);
    void DestroySceneActor(const FString& RuntimeReference);

    void BeginInitialPlayerStreamingIfNeeded();
    void WaitForPlayerActor();
    void WaitForPlayerLoad();
    void ScheduleWaitForPlayerActor();
    void ScheduleWaitForPlayerLoad();
    bool ResolveInitialCharacterIndex();
    int32 FindNextLoadableCharacterIndex(int32 StartIndex) const;
    void RequestCharacterAtIndex(int32 CharacterIndex, bool bIsInitialLoad);
    void HandlePlayerLoadFailure(const FString& Reason);
    void CompletePlayerStreamingWithExistingCharacter(const FString& Reason);
    void ActivatePlayerIfWorldReady();
    void PersistCurrentPlayerSelection();
    ACharacterController* GetPlayerCharacter() const;
    void DeactivatePlayerCharacter();

    void ClearTimers();
    void WriteLogAsync(const FString& Message) const;
};
